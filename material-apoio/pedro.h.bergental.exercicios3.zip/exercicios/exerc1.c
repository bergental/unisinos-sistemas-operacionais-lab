#include <stdio.h>

int main(){
 float a = 3.14159;
 printf("Olá Mundo\n");
 printf("%.3f\n", a);
 return 0;
}
