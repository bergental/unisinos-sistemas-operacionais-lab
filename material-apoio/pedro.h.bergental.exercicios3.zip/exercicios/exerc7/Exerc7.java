public class Exerc7 {

    public static void main(String args[]) {
        String string = "Teste";
        char[] characters = string.toCharArray();
        for (int i = 0; i < characters.length; i++) {
            System.out.println(characters[i]);
        }
    }
}